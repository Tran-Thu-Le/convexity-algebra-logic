D = ['0','a','b','1']

def join(x,y):
    if x==y: return x
    if x=='0': return y
    if y=='0': return x
    if x=='1' or y=='1': return '1'
    return '1'  # a^b = 1

def plus(x,y):  # + = meet
    if x==y: return x
    if x=='1': return y
    if y=='1': return x
    return '0'  # a+b = 0 (0+anything khac = 0 khi ca hai la a,b khac nhau)

def star(x):
    return {'0':'1','1':'0','a':'a','b':'b'}[x]

em='0'; ez='1'
zero = star(ez)

def preceq(u,v):
    return join(u,v)==u

print("="*70)
print("BANG PHEP TOAN")
print("="*70)
print("^ (join):")
print("   ", "  ".join(D))
for x in D:
    print(x, " ", "  ".join(join(x,y) for y in D))
print()
print("+ (meet/tensor):")
print("   ", "  ".join(D))
for x in D:
    print(x, " ", "  ".join(plus(x,y) for y in D))
print()
print("star:", {x:star(x) for x in D})
print("em =", em, " ez =", ez, " zero=star(ez) =", zero)
print()

print("="*70)
print("KIEM TRA 11 TIEN DE PS")
print("="*70)
results = {}
results['M0 (x^x=x)']        = all(join(x,x)==x for x in D)
results['M1 (assoc ^)']      = all(join(join(x,y),z)==join(x,join(y,z)) for x in D for y in D for z in D)
results['M2 (comm ^)']       = all(join(x,y)==join(y,x) for x in D for y in D)
results['M3 (x^em=x)']       = all(join(x,em)==x for x in D)
results['S1 (assoc +)']      = all(plus(plus(x,y),z)==plus(x,plus(y,z)) for x in D for y in D for z in D)
results['S2 (comm +)']       = all(plus(x,y)==plus(y,x) for x in D for y in D)
results['S3 (x+ez=x)']       = all(plus(x,ez)==x for x in D)
results['SM1 (phan phoi)']   = all(plus(x,join(y,z))==join(plus(x,y),plus(x,z)) for x in D for y in D for z in D)
results['SM2 (x+em=em)']     = all(plus(x,em)==em for x in D)
results['P (star^2=id)']     = all(star(star(x))==x for x in D)
results['PM (order-reversing)'] = all((join(x,y)==x) == (join(star(y),star(x))==star(y)) for x in D for y in D)

for k,v in results.items():
    print(f"  {k:30s} : {'OK' if v else 'FAIL'}")
all_ok = all(results.values())
print()
print(">>> TAT CA 11 TIEN DE PS THOA MAN:", all_ok)
print()

print("="*70)
print("KIEM TRA: KHONG TON TAI q (moi q deu bi pha vo boi mot cap a,b)")
print("="*70)
any_q_survives = False
for q in D:
    counterexamples = []
    for a in D:
        for b in D:
            lhs = preceq(plus(a,b), q)
            rhs = preceq(b, star(a))
            if lhs != rhs:
                counterexamples.append((a,b,lhs,rhs))
    survives = (len(counterexamples)==0)
    if survives: any_q_survives = True
    print(f"q = {q}: bien-dieu-kien dung cho MOI (a,b)? {survives}")
    if not survives:
        a,b,lhs,rhs = counterexamples[0]
        print(f"        -> phan vi du dau tien: a={a}, b={b}  "
              f"[(a+b)preceq q]={lhs}  vs  [b preceq star(a)]={rhs}")
print()
print(">>> TON TAI q lam viec (dualizing element)?", any_q_survives)
print(">>> KET LUAN: day la PS hop le nhung KHONG the la BGA (voi star nay).")
