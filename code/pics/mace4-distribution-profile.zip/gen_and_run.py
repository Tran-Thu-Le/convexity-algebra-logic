#!/usr/bin/env python3
"""
Sinh 5 file input cho Mace4: mỗi file gồm 11 tien de cua polar semiring,
cong voi DUY NHAT MOT trong 5 luat phan phoi con lai (D2..D6) bi pha vo
(duoi dang 'exists x,y,z: ... != ...').

Sau do goi mace4 tren tung file va luu ket qua (model neu tim duoc) vao
5 file output tuong ung.

Cach dung:
    python3 gen_and_run.py

Yeu cau: bien MACE4 duoi day tro dung toi binary mace4 da build.
"""

import subprocess
import os

MACE4 = "/home/claude/ladr-main/bin/mace4"
START_SIZE = 2
END_SIZE = 12
MAX_MODELS = 1
TIMEOUT_SEC = 60  # gioi han thoi gian cho moi lan chay mace4

# ----------------------------------------------------------------------
# 11 tien de cua polar semiring (chung cho ca 5 file)
# ----------------------------------------------------------------------
AXIOMS_11 = """
% ================================================================
% 11 tien de cua polar semiring
% ================================================================

% M0: idempotence of plus
x ^ x = x.

% M1: associativity of plus
x ^ (y ^ z) = (x ^ y) ^ z.

% M2: commutativity of plus
x ^ y = y ^ x.

% M3: unit of plus
x ^ em = x.

% S1: associativity of tensor
x + (y + z) = (x + y) + z.

% S2: commutativity of tensor
x + y = y + x.

% S3: unit of tensor
x + ez = x.

% SM1: tensor distributes over plus
x + (y ^ z) = (x + y) ^ (x + z).

% SM2: em is absorbing for tensor
x + em = em.

% P: involutive polarity
star(star(x)) = x.

% PM: polarity reverses the order induced by plus
(x ^ y = x) <-> (star(y) ^ star(x) = star(y)).
"""

# ----------------------------------------------------------------------
# Dinh nghia hai toan tu doi ngau (with, parr)
# ----------------------------------------------------------------------
DUAL_DEFS = """
% ================================================================
% Dinh nghia hai toan tu doi ngau cua polarity
% ================================================================

with(x,y) = star(star(x) ^ star(y)).
parr(x,y) = star(star(x) + star(y)).
"""

# ----------------------------------------------------------------------
# 5 luat phan phoi con lai (D2..D6) - moi luat se bi pha vo RIENG LE
# trong tung file
# ----------------------------------------------------------------------
DISTRIB_LAWS = {
    "D2": {
        "desc": "tensor khong phan phoi qua with",
        "formula": "exists x exists y exists z\n"
                   "  (x + with(y,z) != with(x + y, x + z))."
    },
    "D3": {
        "desc": "tensor khong phan phoi qua parr",
        "formula": "exists x exists y exists z\n"
                   "  (x + parr(y,z) != parr(x + y, x + z))."
    },
    "D4": {
        "desc": "plus khong phan phoi qua tensor",
        "formula": "exists x exists y exists z\n"
                   "  (x ^ (y + z) != (x ^ y) + (x ^ z))."
    },
    "D5": {
        "desc": "plus khong phan phoi qua with",
        "formula": "exists x exists y exists z\n"
                   "  (x ^ with(y,z) != with(x ^ y, x ^ z))."
    },
    "D6": {
        "desc": "plus khong phan phoi qua parr",
        "formula": "exists x exists y exists z\n"
                   "  (x ^ parr(y,z) != parr(x ^ y, x ^ z))."
    },
}


def build_mace4_input(law_name, law_info):
    """Tao noi dung file input Mace4 cho mot luat Di bi pha vo."""
    lines = []
    lines.append(f"% Mace4 input: 11 tien de polar semiring + {law_name} bi vo")
    lines.append(f"% ({law_info['desc']})")
    lines.append("")
    lines.append(f"assign(start_size,{START_SIZE}).")
    lines.append(f"assign(end_size,{END_SIZE}).")
    lines.append(f"assign(max_models,{MAX_MODELS}).")
    lines.append("")
    lines.append('op(400,infix,"^").')
    lines.append('op(500,infix,"+").')
    lines.append("")
    lines.append("formulas(assumptions).")
    lines.append(AXIOMS_11.strip())
    lines.append("")
    lines.append(DUAL_DEFS.strip())
    lines.append("")
    lines.append(f"% {law_name} bi vo: {law_info['desc']}")
    lines.append(law_info["formula"])
    lines.append("")
    lines.append("end_of_list.")
    lines.append("")
    return "\n".join(lines)


def main():
    here = os.path.dirname(os.path.abspath(__file__))
    for law_name, law_info in DISTRIB_LAWS.items():
        in_path = os.path.join(here, f"{law_name}.in")
        out_path = os.path.join(here, f"{law_name}.out")

        content = build_mace4_input(law_name, law_info)
        with open(in_path, "w") as f:
            f.write(content)
        print(f"[+] Da tao {in_path}")

        print(f"[*] Dang chay mace4 cho {law_name} (timeout {TIMEOUT_SEC}s)...")
        try:
            result = subprocess.run(
                [MACE4, "-f", in_path],
                capture_output=True,
                text=True,
                timeout=TIMEOUT_SEC,
            )
            output = result.stdout
            if result.stderr:
                output += "\n% ----- stderr -----\n" + result.stderr
        except subprocess.TimeoutExpired as e:
            output = (e.stdout or "")
            output += (
                f"\n% ----- TIMEOUT sau {TIMEOUT_SEC}s, khong tim thay model "
                f"trong khoang domain size [{START_SIZE},{END_SIZE}] -----\n"
            )

        with open(out_path, "w") as f:
            f.write(output)

        found = "Exiting with 1 model" in output or "MODEL" in output.upper()
        status = "TIM THAY MODEL" if found else "KHONG TIM THAY / LOI"
        print(f"[=] {law_name}: {status} -> {out_path}\n")


if __name__ == "__main__":
    main()
